<?php
namespace Mooc\UI\DemoBlock;

use Mooc\UI\Block;

class DemoBlock extends Block 
{
    const NAME = 'Demo';

    public function initialize()
    {
        $this->defineField('demo_conten', \Mooc\SCOPE_BLOCK, '');
    }

    public function student_view()
    {   
        $this->setGrade(1.0);

        return array_merge($this->getAttrArray(), array());
    }

    public function author_view()
    {
        $this->authorizeUpdate();

        return array_merge($this->getAttrArray(), array());
    }

    private function getAttrArray() 
    {
        return array(
            'demo_content' => $this->demo_content
        );
    }

    public function save_handler(array $data)
    {
        $this->authorizeUpdate();

        if (isset ($data['demo_content'])) {
            $this->demo_content = (string) $data['demo_content'];
        } 

        return;
    }

    public function exportProperties()
    {
       return $this->getAttrArray();
    }

    public function getXmlNamespace()
    {
        return 'http://moocip.de/schema/block/demo/';
    }

    public function getXmlSchemaLocation()
    {
        return 'http://moocip.de/schema/block/demo/demo-1.0.xsd';
    }

    public function importProperties(array $properties)
    {
        if (isset($properties['demo_content'])) {
            $this->demo_content = $properties['demo_content'];
        }

        $this->save();
    }
}
