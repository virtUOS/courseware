import $ from 'jquery'
import StudentView from 'js/student_view'
import helper from 'js/url'

export default StudentView.extend({
  events: {
  },

  initialize() { },

  render() {
    return this;
  },

  postRender() {
    return this;
  },

});
